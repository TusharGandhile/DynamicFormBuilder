import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SubjectService } from '../subject.service';
@Component({
  selector: 'app-form-component2-dynamic',
  templateUrl: './form-component2-dynamic.component.html',
  styleUrls: ['./form-component2-dynamic.component.scss']
})
export class FormComponent2DynamicComponent implements OnInit {
formarr:any=[];
myFormGroup!:FormGroup;
form_template = [
  {
    "type":"textBox",
    "label":"Name",
  },
  {
    "type":"number",
    "label":"Age"
  },
  {
    "type":"select",
    "label":"favorite book",
    "options":["Jane Eyre","Pride and Prejudice","Wuthering Heights"]
  },
  {
    "type":"checkbox",
    "label":"Hobbies",
    "options":["Swimming","Reading","Dancing"]
  }
]
  formTemplate:any = this.form_template; 
  constructor(private appService:SubjectService) { }

  ngOnInit(): void {
    this.appService.stringSubject.subscribe((data: any) => {
      console.log(data);
      this.formarr = data;
  })
  let group: { [key: string]: any }={}    
    this.form_template.forEach(e=>{
       group[e.label]=new FormControl('');  
    })
    this.myFormGroup = new FormGroup(group);
  }
  onSubmit(){
    console.log(this.myFormGroup.value);
  }
}
