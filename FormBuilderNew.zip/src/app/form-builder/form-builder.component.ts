import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SubjectService } from '../subject.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss']
})
export class FormBuilderComponent implements OnInit {
  @ViewChild('frm') frm!: NgForm;
  formarray:any=[]
  opt:any=[];
  option=false;
  constructor(private appService:SubjectService) { }

  ngOnInit(): void {
    if(localStorage.getItem('formvalue')){
      this.formarray=JSON.parse(localStorage.getItem('formvalue')!)
    }
  }
addField(){
  if(this.frm.value.options!=null){
  console.log(this.frm.value);
  this.opt=this.frm.value.options
  console.log(this.opt);
  let option = this.opt.split(',');
  this.frm.value.options=option;
  }
  this.formarray.push(this.frm.value)
 // localStorage.setItem('formvalue',JSON.stringify(this.formarray))
  this.appService.passValue(this.formarray);
  this.frm.reset();
}
changeField(val:any){
  if(val=='radio' || val=='checkbox' || val=='select'){
    this.option=true;
    }
  else{
    this.option=false;
  }


}

}
