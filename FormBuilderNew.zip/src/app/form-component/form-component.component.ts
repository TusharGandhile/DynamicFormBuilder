import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm } from '@angular/forms';

import { SubjectService } from '../subject.service';
// import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-component',
  templateUrl: './form-component.component.html',
  styleUrls: ['./form-component.component.scss']
})
export class FormComponentComponent implements OnInit {
  formval: any = [];
  formarr: any = [];
  b: any = [];
  a: any = [];
  an: any
  name: any;

  @ViewChild('frmval') frmval!: NgForm;
  registrationForm!: FormGroup;
  constructor(private appService: SubjectService, private formBuilder: FormBuilder) { }
  formData: any = new FormData();
  ngOnInit(): void {

    this.appService.stringSubject.subscribe((data: any) => {
      console.log(data);
      this.formarr = data;
    })


  }


  submit() {

    //    const check=this.formarr.fname
    //     for (let m = 0; m < this.formarr.length; m++) {
    //       if (this.formarr[m].fields == 'checkbox') {
    //         this.frmval.value.check= this.b;
    //         console.log(this.frmval.value);
    //       }
    //       else {
    console.log(this.frmval.value);

    //       }
    console.log(this.formData);
    for (var pair of this.formData.entries()) {
      console.log(pair[0] + ':{' + pair[1] + "}");
    }
    //}
    this.frmval.reset();
    this.b = []
  }
  changeCheck(e: any, val: any) {




    let flag = false
    let x: any;
    // if(this.b.length==0)  this.b.push({name:val.fname,
    // value:e.target.value})
    this.b = this.b.filter((obj: any) => obj.value === e.target.value).length > 0 ? this.b.filter((obj: any) => obj.value !== e.target.value) : [...this.b, { name: val.fname, value: e.target.value }]

    // if (flag) {
    //   for (let i = 0; i < this.b.length; i++) this.b[i].value == e.target.value ? this.b.splice(i, 1) : ""
    // }
    // else {

    //   this.b.push({name:val.fname,
    //     value:e.target.value})
    // }
    console.log(this.b);
    let temp: any = []
    for (let i = 0; i < this.b.length; i++) {
      if (this.b[i].name == val.fname) {
        temp.push(this.b[i].value)
      }

    }
    console.log(temp);
    this.formData.has(val.fname) ? this.formData.set(val.fname, temp) : this.formData.append(val.fname, temp);


    let check: any = []
    for (var pair of this.formData.entries()) {
      let str: string = "{" + pair[0] + ":" + pair[1] + "}"

      check.push(str)
      console.log(check);
    }
    this.frmval.value.check = check;
    console.log(this.frmval.value);

  }

  //   let flag = false
  //   let x: any;pair[0]
  //   (this.b.includes(e.target.value)) ? flag = true : "";
  //   if (flag) {
  //     for (let i = 0; i < this.b.length; i++) this.b[i] == e.target.value ? this.b.splice(i, 1) : ""
  //   }
  //   else {

  //     this.b.push(e.target.value)
  //   }
  //   console.log(this.b);

  // }

}



